package dev.ancientdebrisvision;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.lwjgl.glfw.GLFW;

/**
 * Small client-only toggle. It only examines client-loaded blocks; it does not
 * request chunks or send packets to a server.
 */
public final class AncientDebrisVisionClient implements ClientModInitializer {
    private static final int SCAN_RADIUS = 24;
    private static final int MAX_MARKERS_PER_FRAME = 180;
    private static boolean enabled = false;
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.ancientdebrisvision.toggle",
                GLFW.GLFW_KEY_G,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            net.minecraft.network.chat.Component.literal(
                                    "Ancient Debris Vision: " + (enabled ? "ON" : "OFF")),
                            true
                    );
                }
            }
        });

        // The current world-render event is used to keep the feature client-only.
        WorldRenderEvents.LAST.register(context -> {
            if (!enabled || context.world() == null || Minecraft.getInstance().player == null) return;
            // Rendering implementation is intentionally isolated in one helper.
            DebrisOverlay.render(context, SCAN_RADIUS, MAX_MARKERS_PER_FRAME);
        });
    }

    static boolean isEnabled() {
        return enabled;
    }
}

package dev.ancientdebrisvision;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.BufferUploader;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Draws camera-relative orange wireframes for Ancient Debris in loaded blocks. */
final class DebrisOverlay {
    private DebrisOverlay() {}

    static void render(WorldRenderContext context, int radius, int limit) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || context.camera() == null) return;

        BlockPos center = mc.player.blockPosition();
        Vec3 camera = context.camera().position();
        int minY = Math.max(mc.level.getMinY(), center.getY() - radius);
        int maxY = Math.min(mc.level.getMaxY(), center.getY() + radius);

        // Only inspect the already-loaded area around the player.
        BufferBuilder buffer = Tesselator.getInstance().begin(
                VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f matrix = context.matrixStack() != null
                ? context.matrixStack().last().pose()
                : new Matrix4f();
        int drawn = 0;

        for (int x = center.getX() - radius; x <= center.getX() + radius && drawn < limit; x++) {
            for (int y = minY; y <= maxY && drawn < limit; y++) {
                for (int z = center.getZ() - radius; z <= center.getZ() + radius && drawn < limit; z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!mc.level.hasChunkAt(pos) || mc.level.getBlockState(pos).getBlock() != Blocks.ANCIENT_DEBRIS) continue;
                    AABB box = new AABB(x, y, z, x + 1, y + 1, z + 1).move(-camera.x, -camera.y, -camera.z);
                    lineBox(buffer, matrix, box);
                    drawn++;
                }
            }
        }

        if (drawn == 0) return;
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(net.minecraft.client.renderer.GameRenderer::getPositionColorShader);
        RenderSystem.lineWidth(2.0F);
        BufferUploader.drawWithShader(buffer.buildOrThrow());
        RenderSystem.lineWidth(1.0F);
        RenderSystem.enableDepthTest();
    }

    private static void lineBox(BufferBuilder b, Matrix4f m, AABB a) {
        float[][] p = {
                {(float)a.minX,(float)a.minY,(float)a.minZ}, {(float)a.maxX,(float)a.minY,(float)a.minZ},
                {(float)a.maxX,(float)a.minY,(float)a.maxZ}, {(float)a.minX,(float)a.minY,(float)a.maxZ},
                {(float)a.minX,(float)a.maxY,(float)a.minZ}, {(float)a.maxX,(float)a.maxY,(float)a.minZ},
                {(float)a.maxX,(float)a.maxY,(float)a.maxZ}, {(float)a.minX,(float)a.maxY,(float)a.maxZ}
        };
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] e : edges) {
            vertex(b, m, p[e[0]]); vertex(b, m, p[e[1]]);
        }
    }

    private static void vertex(BufferBuilder b, Matrix4f m, float[] p) {
        b.addVertex(m, p[0], p[1], p[2]).setColor(1.0F, 0.45F, 0.05F, 1.0F);
    }
}

# Ancient Debris Vision — Fabric 26.3 project

A minimal client-side mod scaffold intended to highlight Ancient Debris with orange outlines. The requested toggle key is **G**.

## Important status

**This project is not yet a verified working mod.** Minecraft 26.3 changed rendering APIs, and the current Java renderer/keybinding code may need porting before the build succeeds. The cloud workflow below is provided to test the project without installing Java or Gradle locally; it does not guarantee a successful build.

The scanner is intended to inspect only already-loaded client-side blocks around the player. It does not request chunks or send packets. Some multiplayer servers prohibit X-ray/ore-highlighting mods; follow the server rules.

## Build in the cloud (no local Gradle required)

1. Sign in to GitHub and create a **new public repository** named `AncientDebrisVision`.
2. Extract this ZIP on your PC.
3. Open the extracted `AncientDebrisVision` folder. Upload the **contents inside that folder** to the repository root (including the `.github` folder, `src`, `build.gradle`, `gradle.properties`, and `settings.gradle`). Do not upload only the ZIP file or an extra outer folder.
4. In the repository, open **Actions**. If GitHub asks to enable workflows, enable them.
5. Select **Build Fabric mod** on the left and click **Run workflow**. You can also trigger it by committing files.
6. Open the finished workflow run. If it succeeds, find **Artifacts** at the bottom and download `AncientDebrisVision-jar`.
7. If it fails, open the failed **Build mod** step and copy the first compiler error. This source may need a 26.3 API update before it can produce a JAR.

The workflow uses JDK 25 and Gradle 9.6.1 in GitHub's hosted runner, so neither needs to be installed on your PC.
